#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
German-Gamma Modulo 3: Capa Evolutiva y Memoria Adaptativa

Autor y Titular Conceptual: Andres German Garcia
Copyright: (c) 2026 Andres German Garcia. Todos los derechos reservados.

Objetivo:
    Evaluar metricas evolutivas extendidas:
    - mutacion operacional,
    - silenciamiento funcional,
    - amplificacion regulatoria,
    - memoria CRISPR operacional.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def normalize_distribution(values: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    values = np.clip(values, 0.0, None)
    total = float(values.sum())
    if total <= eps:
        raise ValueError("La distribucion no puede normalizarse porque su masa total es cero.")
    return values / total


def kl_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    p = normalize_distribution(p)
    q = normalize_distribution(q)
    p_safe = np.clip(p, eps, 1.0)
    q_safe = np.clip(q, eps, 1.0)
    return float(np.sum(p_safe * np.log2(p_safe / q_safe)))


def js_divergence(p: np.ndarray, q: np.ndarray) -> float:
    p = normalize_distribution(p)
    q = normalize_distribution(q)
    m = 0.5 * (p + q)
    return float(np.clip(0.5 * kl_divergence(p, m) + 0.5 * kl_divergence(q, m), 0.0, 1.0))


def histogram_distribution(series: pd.Series, bins: int = 20, range_: tuple[float, float] | None = None) -> np.ndarray:
    counts, _ = np.histogram(series.to_numpy(dtype=float), bins=bins, range=range_)
    return normalize_distribution(counts + 1e-12)


def shannon_entropy_from_distribution(p: np.ndarray) -> float:
    p = normalize_distribution(p)
    p = p[p > 0]
    if len(p) <= 1:
        return 0.0
    return float(-np.sum(p * np.log2(p)) / np.log2(len(p)))


def load_modulo_1_metrics() -> dict[str, float]:
    out_dir = Path("outputs")
    padre_path = out_dir / "gg_estado_padre.csv"
    inducido_path = out_dir / "gg_medida_inducida.csv"
    silenciado_path = out_dir / "gg_informacion_silenciada.csv"
    if not (padre_path.exists() and inducido_path.exists() and silenciado_path.exists()):
        return {
            "source": "fallback_sintetico",
            "d_js_padre_inducido": 0.48,
            "silenciamiento_funcional": 0.552,
            "brecha_entropia_gamma": 0.35,
        }

    df_padre = pd.read_csv(padre_path)
    df_inducido = pd.read_csv(inducido_path)
    df_silenciado = pd.read_csv(silenciado_path)

    temp_min = float(df_padre["T"].min())
    temp_max = float(df_padre["T"].max())
    range_t = (temp_min, temp_max)
    p_parent = histogram_distribution(df_padre["T"], range_=range_t)
    p_induced = histogram_distribution(df_inducido["T"], range_=range_t)
    p_silenced = histogram_distribution(df_silenciado["T"], range_=range_t)

    d_js_parent_induced = js_divergence(p_parent, p_induced)
    sf_gamma = js_divergence(p_induced, p_silenced)
    h_induced = shannon_entropy_from_distribution(p_induced)
    h_silenced = shannon_entropy_from_distribution(p_silenced)
    entropy_gap = abs(h_induced - h_silenced)

    return {
        "source": "modulo_1_csv",
        "d_js_padre_inducido": float(d_js_parent_induced),
        "silenciamiento_funcional": float(sf_gamma),
        "brecha_entropia_gamma": float(entropy_gap),
    }


def load_modulo_2_metrics() -> dict[str, float]:
    out_dir = Path("outputs")
    summary_path = out_dir / "gg_modulo_2_resumen.json"
    windows_path = out_dir / "gg_resultado_ventanas.csv"
    if not (summary_path.exists() and windows_path.exists()):
        return {
            "source": "fallback_sintetico",
            "delta_omega": 0.58,
            "d_g_sombra_geometrica": 0.42,
            "cf_sombra_composicional": 0.55,
        }

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    df_windows = pd.read_csv(windows_path)
    omega_initial = float(df_windows.iloc[0]["omega"])
    omega_final = float(df_windows.iloc[-1]["omega"])
    delta_omega = float(np.clip(abs(omega_final - omega_initial), 0.0, 1.0))
    d_g_shadow = float(np.clip(df_windows["sombra"].max(), 0.0, 1.0))
    cf_shadow = float(np.clip(abs(omega_final - float(df_windows["omega"].mean())), 0.0, 1.0))

    return {
        "source": str(summary.get("modulo", "modulo_2_csv")),
        "delta_omega": delta_omega,
        "d_g_sombra_geometrica": d_g_shadow,
        "cf_sombra_composicional": cf_shadow,
    }


def desplegar_modulo_3() -> dict[str, object]:
    print("=" * 80)
    print("       GERMAN-GAMMA MODULO 3: CAPA EVOLUTIVA Y MEMORIA ADAPTATIVA")
    print("=" * 80)

    print("[MIGRACION] Extrayendo datos de la capa base para analisis fenotipico...")
    m1 = load_modulo_1_metrics()
    m2 = load_modulo_2_metrics()

    cf_sombra_composicional = float(m2["cf_sombra_composicional"])
    d_js_padre_inducido = float(m1["d_js_padre_inducido"])
    brecha_entropia_gamma = float(m1["brecha_entropia_gamma"])
    d_g_sombra_geometrica = float(m2["d_g_sombra_geometrica"])
    delta_omega = float(m2["delta_omega"])
    silenciamiento_funcional = float(m1["silenciamiento_funcional"])

    print("\n[COMPUTO] Evaluando ecuaciones de la arquitectura extendida...")
    pesos = {
        "w_js": 0.30,
        "w_entropy": 0.30,
        "w_geometric": 0.20,
        "w_compositional": 0.20,
    }
    if not np.isclose(sum(pesos.values()), 1.0):
        raise ValueError("Los pesos de mutacion operacional deben sumar 1.")

    mutacion_operacional = (
        pesos["w_js"] * d_js_padre_inducido
        + pesos["w_entropy"] * abs(brecha_entropia_gamma)
        + pesos["w_geometric"] * d_g_sombra_geometrica
        + pesos["w_compositional"] * abs(cf_sombra_composicional)
    )

    epsilon_estabilidad = 1e-5
    amplificacion_regulatoria = delta_omega / (mutacion_operacional + epsilon_estabilidad)

    print("[MEMORIA] Indexando firma de deformacion en el registro CRISPR de la Sonda...")
    firma_actual = {
        "M_Gamma": round(float(mutacion_operacional), 6),
        "SF_Gamma": round(float(silenciamiento_funcional), 6),
        "A_R": round(float(amplificacion_regulatoria), 6),
        "Delta_Omega": round(float(delta_omega), 6),
    }

    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True)
    crispr_path = out_dir / "gg_crispr_operacional.json"
    if crispr_path.exists():
        registro = json.loads(crispr_path.read_text(encoding="utf-8"))
    else:
        registro = []
    registro.append(firma_actual)
    crispr_path.write_text(json.dumps(registro, indent=2, ensure_ascii=False), encoding="utf-8")

    print("\n" + "-" * 60)
    print("           REPORTE DE METRICAS EVOLUTIVAS EXTENDIDAS")
    print("-" * 60)
    print(f"Fuente M1:                              {m1['source']}")
    print(f"Fuente M2:                              {m2['source']}")
    print(f"Mutacion Operacional (M_Gamma):         {round(float(mutacion_operacional), 4)}")
    print(f"Silenciamiento Funcional (SF_Gamma):    {round(float(silenciamiento_funcional), 4)}")
    print(f"Amplificacion Regulatoria (A_R):        {round(float(amplificacion_regulatoria), 4)}")
    print("Registro CRISPR Operacional:            Firma indexada con exito.")
    print("\n[ESTADO] Modulo evolutivo en cierre geometrico.")
    print("=" * 80 + "\n")

    resumen = {
        "modulo": "German-Gamma Modulo 3",
        "fuente_modulo_1": m1["source"],
        "fuente_modulo_2": m2["source"],
        "pesos_mutacion_operacional": pesos,
        "d_js_padre_inducido": d_js_padre_inducido,
        "brecha_entropia_gamma": brecha_entropia_gamma,
        "d_g_sombra_geometrica": d_g_sombra_geometrica,
        "cf_sombra_composicional": cf_sombra_composicional,
        "delta_omega": delta_omega,
        "mutacion_operacional": float(mutacion_operacional),
        "silenciamiento_funcional": float(silenciamiento_funcional),
        "amplificacion_regulatoria": float(amplificacion_regulatoria),
        "firma_crispr": firma_actual,
        "registro_crispr_n": len(registro),
    }
    (out_dir / "gg_modulo_3_resumen.json").write_text(
        json.dumps(resumen, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print("[OK] Exportado: outputs/gg_modulo_3_resumen.json")
    print("[OK] Exportado: outputs/gg_crispr_operacional.json")
    return resumen


if __name__ == "__main__":
    desplegar_modulo_3()
