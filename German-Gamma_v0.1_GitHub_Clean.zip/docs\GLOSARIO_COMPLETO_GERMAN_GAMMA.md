# Glosario Completo German-Gamma

**Autor y Titular Conceptual:** Andres German Garcia  
**Copyright:** (c) 2026 Andres German Garcia. Todos los derechos reservados.  
**Estado:** glosario maestro completo con definiciones operacionales y matemática asociada.  
**Uso:** documentación de referencia, apéndice técnico, base de paper, código y auditoría.

---

## 0. Principios Rectores

### 0.1 Regla Editorial

German-Gamma puede usar analogías evolutivas, biológicas o informacionales para orientar el descubrimiento, pero el modelo queda definido únicamente por operaciones cuantitativas.

> La analogía orienta; la métrica define.

### 0.2 Regla de Trazabilidad

Toda afirmación cualitativa debe estar respaldada por una deformación cuantitativa trazable.

\[
\text{Afirmación válida}
\Rightarrow
\text{métrica definida}
+
\text{umbral explícito}
+
\text{procedimiento reproducible}
\]

### 0.3 Regla de Viabilidad

No todo escenario matemáticamente imaginable pertenece al dominio operacional del sistema.

\[
F_t^{(k)}\in\mathcal{V}
\]

donde \(\mathcal{V}\) es el espacio de viabilidad definido por restricciones físicas, estadísticas y operacionales.

---

## 1. Estado Padre

### Definición

El Estado Padre es el espacio probabilístico antes del filtro crítico:

\[
(\Omega,\mathcal{F},P)
\]

| Símbolo | Significado |
|---|---|
| \(\Omega\) | conjunto de eventos observados o registrables |
| \(\mathcal{F}\) | familia de eventos evaluables |
| \(P\) | medida de probabilidad original |

### Función

Es el soporte base desde el cual se evalúa si una selección, ventana, filtro o transformación cambió el espacio probabilístico.

---

## 2. Cuerpo Operacional

### Definición

Conjunto de sensores, filtros, ventanas, umbrales, software, calibraciones y transformaciones que permite que el Estado Padre se exprese como resultado observable.

\[
\mathcal{B}
=
(\Gamma,W,\theta,C,F)
\]

| Componente | Función |
|---|---|
| \(\Gamma\) | selección o filtro |
| \(W\) | ventana temporal |
| \(\theta\) | parámetros moduladores |
| \(C\) | contexto |
| \(F\) | funcional estadístico |

### Expresión

\[
Resultado=F(T_{\Gamma,\theta}(P\mid C))
\]

### Lectura

No se audita solo el dato; se audita el cuerpo que permitió que el dato se expresara.

---

## 3. Operador de Selección \(\Gamma\)

### Definición

\[
\Gamma:\Omega\rightarrow\{0,1\}
\]

\[
\Gamma(\omega)=\mathbf{1}_E(\omega),
\quad E\in\mathcal{F}
\]

\[
\Gamma(\omega)=1
\quad\text{si el evento sobrevive}
\]

\[
\Gamma(\omega)=0
\quad\text{si el evento no se expresa}
\]

### Condición

\[
P(\Gamma=1)>0
\]

### Medibilidad

Como \(\Gamma\) se define como indicadora de un evento medible \(E\in\mathcal{F}\), \(\Gamma\) es \(\mathcal{F}\)-medible. La selección no rompe el soporte formal del espacio de probabilidad.

### Función

Representa filtros, ventanas temporales, postselección, umbrales, decisiones instrumentales, reglas de software o criterios de aceptación.

---

## 4. Medida Inducida

### Definición

\[
P_\Gamma(A)=P(A\mid\Gamma=1)
\]

\[
P_\Gamma(A)=
\frac{P(A\cap\{\Gamma=1\})}{P(\Gamma=1)}
\]

### Derivada de Radon-Nikodym

\[
\frac{dP_\Gamma}{dP}(\omega)
=
\frac{\mathbf{1}_\Gamma(\omega)}{P(\Gamma=1)}
\]

### Absoluta continuidad

Dado que \(P(\Gamma=1)>0\), para todo \(A\in\mathcal{F}\):

\[
P(A)=0
\Rightarrow
P(A\cap\{\Gamma=1\})=0
\Rightarrow
P_\Gamma(A)=0
\]

Por tanto:

\[
P_\Gamma\ll P
\]

y la derivada de Radon-Nikodym existe.

### Lectura

La medida inducida es la copia operacional expresada del Estado Padre. Conserva información heredada, pero ya contiene la marca del filtro.

---

## 5. Información Expresada

### Definición

\[
\Omega_\Gamma=
\{\omega\in\Omega:\Gamma(\omega)=1\}
\]

\[
P_\Gamma=P(\cdot\mid\Omega_\Gamma)
\]

### Función

Es la porción del Estado Padre que entra al resultado final.

---

## 6. Información Silenciada

### Definición

\[
\Omega_{\neg\Gamma}=
\{\omega\in\Omega:\Gamma(\omega)=0\}
\]

\[
\Omega=\Omega_\Gamma\cup\Omega_{\neg\Gamma}
\]

\[
\Omega_\Gamma\cap\Omega_{\neg\Gamma}=\varnothing
\]

### Medida no expresada

\[
P_{\neg\Gamma}(A)=P(A\mid\Gamma=0)
\]

si:

\[
P(\Gamma=0)>0
\]

### Lectura

Lo no expresado no se descarta como ruido hasta demostrar que carece de estructura, persistencia e impacto regulatorio.

---

## 7. Ruido

### Definición

Componente no persistente, no replicable, no estructurada y sin impacto funcional medible.

\[
I_r=
I_{nc}\setminus I_{reg}
\]

### Criterio operacional

Un componente puede clasificarse como ruido si:

\[
Persistencia<\epsilon_P
\]

\[
D_{JS}(I_r,N)<\epsilon_D
\]

\[
Impacto_\Omega<\epsilon_\Omega
\]

---

## 8. Información Regulatoria

### Definición

Información no necesariamente expresada de forma directa, pero capaz de alterar soporte, selección, entropía, horizonte o interpretación.

\[
I_{reg}\subseteq\Omega_{\neg\Gamma}
\]

### Criterio

\[
I_{reg}
\Longleftrightarrow
D_{JS}(P_{\neg\Gamma},N_{\neg\Gamma})>\epsilon_D
\quad
\text{y}
\quad
Impacto_\Omega>\epsilon_\Omega
\]

---

## 9. Silenciamiento Funcional

### Definición

Condición en la cual una porción del Estado Padre permanece disponible en el soporte, pero no se expresa en el resultado final debido a \(\Gamma\).

\[
SF_\Gamma=
D_{JS}(P_\Gamma,P_{\neg\Gamma})
\]

### Lectura

| Valor | Interpretación |
|---|---|
| \(SF_\Gamma\approx0\) | lo expresado y lo silenciado son similares |
| \(SF_\Gamma>\epsilon_{SF}\) | lo silenciado tiene geometría distinta |
| alto y persistente | posible información regulatoria no expresada |

---

## 10. Clon Padre

### Definición

Réplica contrafactual del Estado Padre que conserva restricciones basales del soporte, pero neutraliza la composición específica que se audita.

\[
P_0^*
\]

### Criterio

\[
D(P,P_0^*)\approx0
\]

respecto a las restricciones preservadas.

### Función

Distingue sesgo basal de sesgo inducido:

| Escenario | Lectura |
|---|---|
| deformación en \(P\) y \(P_0^*\) | posible sesgo basal |
| deformación aparece tras \(\Gamma\) | posible sesgo inducido |

---

## 11. Clon Neutro

### Definición

Control contrafactual comparable al Estado Natural observado:

\[
N_\Gamma^*
\]

Debe preservar restricciones externas relevantes, pero romper la composición específica del filtro real.

### Comparación

\[
D_{JS}(P_\Gamma,N_\Gamma^*)
\]

### Función

Pregunta si la estructura observada aparece bajo una geometría neutral comparable.

---

## 12. Estado Natural

### Definición

Estado empírico real después de aplicar \(\Gamma\):

\[
P_\Gamma
\]

En ventanas temporales:

\[
R_t=P(X\mid W_t,\Gamma=1)
\]

### Lectura

Es la expresión observada del sistema bajo el cuerpo operacional.

---

## 13. Punto Neutro

### Definición

Origen local de mínima deformación:

\[
\nu_t
\]

Distancia:

\[
\Psi_t=D(R_t,\nu_t)
\]

### Métrica recomendada

Si \(R_t\) y \(\nu_t\) son distribuciones:

\[
D(R_t,\nu_t)=\sqrt{D_{JS}(R_t,\nu_t)}
\]

La raíz de Jensen-Shannon es una métrica. Si \(R_t\) y \(\nu_t\) son vectores de parámetros físicos normalizados:

\[
D(R_t,\nu_t)=\|z(R_t)-z(\nu_t)\|_2
\]

donde \(z(\cdot)\) denota coordenadas normalizadas.

### Lectura

No es un punto absoluto de verdad; es una referencia local de comparación.

---

## 14. Estado Natural como Banda

### Definición

El estado natural no es un punto fijo, sino una banda de variabilidad compatible:

\[
\mathcal{N}_t=
\{R:D(R,\nu_t)\leq\epsilon_N\}
\]

Distancia al estado natural:

\[
\Phi_t=D(R_t,\mathcal{N}_t)
\]

### Lectura

German-Gamma no confunde variabilidad con anomalía.

---

## 15. Variabilidad Basal

### Definición

\[
Var_t=D(R_t,R_{t-1})
\]

### Criterio

\[
Var_t\leq Var_{natural}
\Rightarrow
\text{variabilidad compatible}
\]

\[
Var_t>Var_{natural}
\Rightarrow
\text{posible deformación}
\]

---

## 16. Ventana Temporal

### Definición

\[
W_t=[t-\Delta t,t]
\]

Estado empírico de ventana:

\[
\hat{R}_t=
\{\hat{p}_i(t)\}_{i=1}^{m}
\]

### Función

Permite evaluar persistencia, transición, memoria, apelación temporal y pre-fenotipo.

---

## 17. Sombra como Memoria

### Definición

\[
\mathcal{S}_t=
\lambda\mathcal{S}_{t-1}
+
(1-\lambda)\Delta_t
\]

con:

\[
0<\lambda<1
\]

### Lectura

La sombra no conserva todo el pasado; conserva deformación residual.

---

## 18. Sombra Geométrica

### Definición

Para tasas de aceptación 2x2:

\[
r_{ab}=P(\Gamma=1\mid a,b)
\]

\[
I_G=
\frac{r_{00}r_{11}}{r_{01}r_{10}}
\]

\[
D_G=|\log I_G|
\]

### Criterio

| Valor | Lectura |
|---|---|
| \(I_G=1\) | geometría multiplicativamente neutra |
| \(I_G\neq1\) | deformación o interacción de soporte |
| \(D_G=0\) | sin sombra geométrica |
| \(D_G>0\) | sombra geométrica activa |

---

## 19. Sombra Composicional

### Definición

Para un funcional estadístico \(F\):

\[
C_F=
F(P_\Gamma)-
\mathbb{E}[F(N_\Gamma^*)]
\]

### Lectura

Mide la separación funcional entre el estado expresado y el control neutro.

---

## 20. Colisión de Sombras

### Definición

\[
K_{abs}=D_G|C_F|
\]

\[
K_{signed}=\log(I_G)C_F
\]

### Lectura

| Métrica | Función |
|---|---|
| \(K_{abs}\) | intensidad conjunta soporte-composición |
| \(K_{signed}\) | orientación dependiente de convención |

---

## 21. Entropía

### Definición

\[
H(R_t)=
-\sum_{i=1}^{m}p_i(t)\log p_i(t)
\]

con:

\[
0\log0=0
\]

### Entropía normalizada

\[
H^*(R_t)=
\frac{H(R_t)}{\log m}
\]

para \(m>1\).

### Brecha entrópica

\[
\Delta H_t=
|H^*(R_t)-H^*(N_t)|
\]

---

## 22. Entropía Desplazada

### Definición

Evalúa si el orden del resultado expresado se obtuvo desplazando variabilidad hacia lo no expresado.

\[
ED_\Gamma=
H(P_{\neg\Gamma})-H(P_\Gamma)
\]

### Lectura

| Valor | Interpretación |
|---|---|
| \(ED_\Gamma>0\) | lo silenciado carga más dispersión |
| \(ED_\Gamma\approx0\) | dispersión comparable |
| \(ED_\Gamma<0\) | lo expresado carga más dispersión |

---

## 23. Divergencia Jensen-Shannon

### Definición

\[
M=\frac{1}{2}(P+Q)
\]

\[
D_{JS}(P,Q)=
\frac{1}{2}D_{KL}(P||M)
+
\frac{1}{2}D_{KL}(Q||M)
\]

\[
D_{KL}(P||Q)=
\sum_i p_i\log\frac{p_i}{q_i}
\]

Con logaritmo base 2:

\[
D_{JS}(P,Q)\in[0,1]
\]

---

## 24. Dependencia Inducida

### Definición

Para evento favorable \(Y=1\):

| | \(Y=1\) | \(Y=0\) |
|---|---:|---:|
| \(\Gamma=1\) | \(a\) | \(c\) |
| \(\Gamma=0\) | \(b\) | \(d\) |

\[
OR_\Gamma=
\frac{ad}{bc}
\]

Corrección Haldane-Anscombe:

\[
OR_\Gamma^{HA}=
\frac{(a+0.5)(d+0.5)}
{(b+0.5)(c+0.5)}
\]

### Lectura

Mide si sobrevivir al filtro está asociado con resultado favorable.

---

## 25. Espejo

### Definición

Transformación complementaria usada para evaluar inversión, estabilidad o compensación de una firma.

\[
M_t=\mathcal{M}(R_t)
\]

### Elasticidad espejo

Para una métrica \(Q\):

\[
\Delta_{real}=Q(R_t)-Q(R_{t-1})
\]

\[
\Delta_{mirror}=Q(M_t)-Q(R_{t-1})
\]

\[
E_t=
1-
|\Delta_{real}+\Delta_{mirror}|
\]

Normalizado:

\[
E_t^*\in[0,1]
\]

---

## 26. Decoherencia Espejo

### Definición

Mide si el espejo no invierte o no compensa la firma esperada.

\[
Decoh_M=
|C_{directo}+C_{espejo}|
\]

### Lectura

| Valor | Interpretación |
|---|---|
| bajo | espejo compensa o invierte |
| alto | ruptura de coherencia especular |

---

## 27. Horizonte German-Gamma \(\Omega\)

### Definición

\[
\Omega(W_t)
=
\alpha D_{JS}^{*}
+
\beta\mathcal{S}^{*}
+
\gamma(1-E^{*})
+
\delta Z^{*}
+
\eta\Delta H^{*}
+
\kappa\Phi^{*}
+
\mu\Psi^{*}
+
\theta A_t^{*}
\]

con:

\[
\alpha+\beta+\gamma+\delta+\eta+\kappa+\mu+\theta=1
\]

\[
\alpha,\beta,\gamma,\delta,\eta,\kappa,\mu,\theta\geq0
\]

\[
X^*\in[0,1]
\]

### Micro-glosario de términos normalizados

| Término | Definición operacional |
|---|---|
| \(D_{JS}^{*}\) | \(D_{JS}(R_t,N_t)\), con log base 2 |
| \(\mathcal{S}^{*}\) | sombra normalizada, por ejemplo \(\min(1,D_G/\tau_G)\) o \(\min(1,|C_F|/\tau_C)\) |
| \(E^{*}\) | elasticidad espejo normalizada en \([0,1]\) |
| \(Z^{*}\) | información caliente normalizada |
| \(\Delta H^{*}\) | \(|H^*(R_t)-H^*(N_t)|\) |
| \(\Phi^{*}\) | \(\min(1,D(R_t,\mathcal{N}_t)/\tau_{\mathcal{N}})\) |
| \(\Psi^{*}\) | \(\min(1,D(R_t,\nu_t)/\tau_\nu)\) |
| \(A_t^{*}\) | asimetría temporal normalizada |

Los umbrales \(\tau_G,\tau_C,\tau_{\mathcal{N}},\tau_\nu\) deben declararse antes del análisis.

### Lectura

\[
\Omega_t=\text{¿cruzó el horizonte?}
\]

---

## 28. Apelación Temporal

### Definición

Una firma aislada no se declara estructural hasta persistir durante varias ventanas.

Alerta:

\[
\Omega(W_t)>\Omega_c
\]

Confirmación:

\[
\Omega(W_t),...,\Omega(W_{t+k-1})>\Omega_c
\]

### Elección de \(k\)

\(k\) debe fijarse antes del análisis. Regla recomendada:

\[
k=\max\left(2,\left\lceil\frac{\ell_c}{s}\right\rceil\right)
\]

donde:

| Símbolo | Significado |
|---|---|
| \(\ell_c\) | longitud de correlación temporal estimada en el clon neutro |
| \(s\) | paso entre ventanas consecutivas |

Si no se estima \(\ell_c\), se debe reportar un valor conservador predefinido, por ejemplo \(k=3\), con análisis de sensibilidad.

### Regla

\[
H_1=
\begin{cases}
1, & \Omega(W_t)>\Omega_c \text{ durante } k \text{ ventanas consecutivas}\\
0, & \text{en caso contrario}
\end{cases}
\]

---

## 29. Observación Pre-Fenotípica

### Definición

Detección de reorganización interna antes de que se exprese el evento final.

\[
\Omega_t\uparrow
\quad
\text{antes de}
\quad
Y_{t+\Delta}=1
\]

Forma predictiva:

\[
P(Y_{t+\Delta}=1
\mid
\Omega_t,\mathcal{S}_t,\Delta H_t,E_t)
>
P(Y_{t+\Delta}=1)
\]

---

## 30. Mutación Operacional

### Definición

\[
\mathcal{M}_\Gamma=
D(P,P_\Gamma)
\]

Forma compuesta:

\[
\mathcal{M}_\Gamma=
w_1D_{JS}(P,P_\Gamma)
+
w_2|\Delta H_\Gamma|
+
w_3D_G
+
w_4|C_F|
\]

\[
\sum_i w_i=1,\quad w_i\geq0
\]

---

## 31. Adaptación Operacional

### Definición

\[
A_\Gamma=
\frac{1}{T}
\sum_{t=1}^{T}
\mathbf{1}(\mathcal{M}_{\Gamma,t}>\epsilon_M)
\]

Versión reforzada:

\[
A_\Gamma^*=
A_\Gamma(1-q_{FDR})(1-Decoh_M)
\]

---

## 32. Transferencia Lateral de Medida

### Definición

\[
P_\Gamma=
T_\Gamma(P\mid C_t+L_t)
\]

Efecto lateral:

\[
L_\Gamma=
D_{JS}
(
P_\Gamma^{sin\ L},
P_\Gamma^{con\ L}
)
\]

Razón de supervivencia:

\[
R_L=
\frac{P(\Gamma=1\mid L_t=1)}
{P(\Gamma=1\mid L_t=0)}
\]

---

## 33. Modulación Operacional

### Definición

\[
P_\Gamma(t)=T_{\Gamma,\theta_t}(P\mid C_t)
\]

\[
\mathcal{L}_t=
D(
T_{\Gamma,\theta_t}(P),
T_{\Gamma,\theta_0}(P)
)
\]

### Lectura

El sistema no cambia necesariamente lo que contiene; cambia cómo lo expresa.

---

## 34. Plasticidad Operacional

### Definición

Si:

\[
D_{JS}(P_1,P_2)\approx0
\]

pero:

\[
D_{JS}(P_{\Gamma,1},P_{\Gamma,2})>\epsilon_\Pi
\]

entonces:

\[
\Pi_t=
D_{JS}(P_{\Gamma,1},P_{\Gamma,2})
\]

---

## 35. Amplificación Regulatoria

### Definición

\[
A_R=
\frac{\Delta\Omega}
{\mathcal{M}_\Gamma+\epsilon}
\]

### Lectura

Mide cuándo un cambio pequeño genera efecto grande.

---

## 36. Patrón Generativo Operacional

### Definición

Regla o firma informacional que produce estructura estable bajo contextos variables.

\[
G_p=
\frac{
Persistencia\cdot Replicabilidad
}
{Costo\ Entropico+\epsilon}
\]

### Lectura

La información generativa no solo describe qué es el sistema; define cómo puede producir estructura.

---

## 37. Cuello de Botella Operacional

### Definición

Por soporte:

\[
B_N(t)=
1-\frac{N_t}{N_{t-1}}
\]

Por entropía:

\[
B_H(t)=
1-\frac{H^*(R_t)}
{H^*(R_{t-1})+\epsilon}
\]

---

## 38. Especiación Operacional

### Definición

Separación persistente de trayectorias:

\[
D_{JS}(L_1(t),L_2(t))>\epsilon_L
\]

durante \(k\) ventanas consecutivas.

---

## 39. Híbrido Operacional

### Definición

\[
R_H(t)=
\lambda R_A(t)+(1-\lambda)R_B(t)
\]

\[
0\leq\lambda\leq1
\]

### Híbrido estéril

\[
Persistencia(R_H)<\epsilon_P
\]

---

## 40. Información Caliente

### Definición

\[
Z_t=
D_{local}(R_t,N_t)
\cdot
Persistencia_t
\cdot
Impacto_t
\]

### Lectura

Región prioritaria de auditoría, no prueba causal por sí sola.

---

## 41. CRISPR Operacional

### Definición

Memoria adaptativa de firmas de deformación:

\[
\mathcal{C}_t=
\mathcal{C}_{t-1}
\cup
\{\sigma(\Delta_t)\}
\]

Coincidencia futura:

\[
CRISPR_t=
\max_{j<t}Sim(\sigma_t,\sigma_j)
\]

---

## 42. Código Operacional Binario

### Definición

\[
B_t=(b_1,b_2,\dots,b_n)
\]

Ejemplos:

| Bit | Pregunta |
|---|---|
| \(b_1\) | ¿\(\Omega_t>\Omega_c\)? |
| \(b_2\) | ¿\(\mathcal{S}_t>\epsilon_S\)? |
| \(b_3\) | ¿\(D_{JS}>\epsilon_D\)? |
| \(b_4\) | ¿\(\Delta H>\epsilon_H\)? |
| \(b_5\) | ¿\(E_t<\epsilon_E\)? |

Mutación binaria:

\[
d_H(B_t,B_{t-1})
\]

donde \(d_H\) es distancia de Hamming.

---

## 43. Factor \(G\)

### Definición

\[
G_t=
w_v\mathcal{V}_t
+
w_m\mathcal{M}_t
+
w_a\mathcal{A}_t
+
w_r\mathcal{R}_t
+
w_b\mathcal{B}_t
+
w_x\mathcal{X}_t
\]

\[
\sum_i w_i=1,\quad w_i\geq0
\]

| Término | Significado |
|---|---|
| \(\mathcal{V}_t\) | herencia vertical |
| \(\mathcal{M}_t\) | mutación operacional |
| \(\mathcal{A}_t\) | adaptación operacional |
| \(\mathcal{R}_t\) | amplificación regulatoria |
| \(\mathcal{B}_t\) | cuello de botella |
| \(\mathcal{X}_t\) | transferencia lateral |

### Diferencia

\[
\Omega_t=\text{¿cruzó el horizonte?}
\]

\[
G_t=\text{¿qué tipo de evolución produjo o acompañó ese cruce?}
\]

---

## 44. Cooperación-Ruptura

### Definición

Estrategia metodológica en la cual el auditor acepta inicialmente la estructura declarada del sistema y solo introduce ruptura interpretativa cuando los controles muestran desviación cuantitativa persistente.

\[
Aceptación
\rightarrow
Reconstrucción
\rightarrow
Control\ neutro
\rightarrow
Prueba
\rightarrow
Dictamen
\]

---

## 45. Correcciones por Comparaciones Múltiples

### Bonferroni

\[
p_{bonf}=\min(1,mp)
\]

### Holm-Bonferroni

Ordenando \(p_{(1)}\leq\dots\leq p_{(m)}\):

\[
p_{holm,(i)}
=
\max_{j\leq i}
\min(1,(m-j+1)p_{(j)})
\]

### Benjamini-Hochberg FDR

\[
q_{(i)}
=
\min_{j\geq i}
\frac{m}{j}p_{(j)}
\]

con:

\[
q_{(i)}\leq1
\]

---

## 46. Hipótesis

### Hipótesis nula

\[
H_0:
\Omega(W_t)\leq\Omega_c
\]

sin persistencia crítica.

### Hipótesis alternativa

\[
H_1:
\Omega(W_t)>\Omega_c
\]

durante \(k\) ventanas consecutivas.

---

## 47. Cadena Central de Expresión

\[
P
\xrightarrow{\Gamma}
P_\Gamma
\xrightarrow{F}
Resultado
\xrightarrow{\mathcal{I}}
Interpretación
\]

### Lectura final

El resultado final no se interpreta solo por su valor numérico, sino por la cadena de expresión probabilística que lo hizo visible.
