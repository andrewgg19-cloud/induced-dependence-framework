"""German-Gamma modules."""

