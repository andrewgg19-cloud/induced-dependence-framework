# German-Gamma

Operational framework for auditing induced measures, temporal horizons and probabilistic geometric reorganization.

**Author and conceptual owner:** Andres German Garcia  
**Copyright:** (c) 2026 Andres German Garcia. All rights reserved.

## Concept

German-Gamma audits the probabilistic expression chain:

```text
P -> Gamma -> P_Gamma -> F(P_Gamma) -> Interpretation
```

It asks whether an observed result is stable under the chain of filtering, induced measurement, temporal persistence and neutral controls that made it visible.

## Install

```bash
pip install -r requirements.txt
```

## Run

Run all modules:

```bash
python run_all.py
```

Run individually:

```bash
python modules/modulo1_estado_padre.py
python modules/modulo2_horizonte_omega.py
python modules/modulo3_capa_evolutiva.py
```

## Modules

| Module | Purpose |
|---|---|
| `modulo1_estado_padre.py` | Builds a parent state, applies a measurable selector and derives \(P_\Gamma\). |
| `modulo2_horizonte_omega.py` | Computes temporal horizon \(\Omega\) and H0/H1 decision. |
| `modulo3_capa_evolutiva.py` | Computes operational mutation, silencing, regulatory amplification and adaptive memory. |

## Outputs

Generated files are written to:

```text
outputs/
```

These files are ignored by Git.

## Documentation

See:

```text
docs/
module_docs/
```

## License

German-Gamma is distributed under a dual license:

- Academic non-commercial use is permitted with attribution.
- Commercial use requires prior written authorization from Andres German Garcia.

See `LICENSE_DUAL_GERMAN_GAMMA.md`.

