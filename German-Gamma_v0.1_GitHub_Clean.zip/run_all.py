#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
German-Gamma v0.1 - Run all modules.

Author and conceptual owner: Andres German Garcia
Copyright: (c) 2026 Andres German Garcia. All rights reserved.
"""

from modules.modulo1_estado_padre import desplegar_modulo_1
from modules.modulo2_horizonte_omega import desplegar_modulo_2
from modules.modulo3_capa_evolutiva import desplegar_modulo_3


def main() -> None:
    desplegar_modulo_1()
    desplegar_modulo_2()
    desplegar_modulo_3()


if __name__ == "__main__":
    main()

