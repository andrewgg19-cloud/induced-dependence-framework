# German-Gamma Modulo 2 - Sonda Forense y Horizonte Omega

**Autor y Titular Conceptual:** Andres German Garcia  
**Copyright:** (c) 2026 Andres German Garcia. Todos los derechos reservados.

## Objetivo

Este modulo demuestra la segunda cadena operacional de German-Gamma:

\[
R_t,N_t,\mathcal{S}_t,E_t,\Delta H_t,\Psi_t
\rightarrow
\Omega(W_t)
\rightarrow
H_0/H_1
\]

Calcula el Horizonte German-Gamma por ventanas temporales, aplica apelacion temporal y emite una decision formal.

## Componentes

| Componente | Funcion |
|---|---|
| \(D_{JS}\) | divergencia real contra clon neutro |
| \(\mathcal{S}\) | sombra normalizada |
| \(E\) | elasticidad espejo |
| \(\Delta H\) | brecha entropica |
| \(\Psi\) | distancia al punto neutro |
| \(\Omega\) | horizonte compuesto |
| \(k\) | apelacion temporal |

## Ecuacion

\[
\Omega(W_t)
=
\alpha D_{JS}^{*}
+
\beta \mathcal{S}^{*}
+
\gamma(1-E^{*})
+
\delta\Delta H^{*}
+
\eta\Psi^{*}
\]

con:

\[
\alpha+\beta+\gamma+\delta+\eta=1
\]

## Apelacion Temporal

\[
k=\max\left(2,\left\lceil\frac{\ell_c}{s}\right\rceil\right)
\]

En este piloto:

```text
longitud_correlacion_neutra = 3
paso_ventana = 1
k = 3
```

## Comando

```powershell
cd "C:\Users\Usuario\Documents\Codex\2026-05-19\auditaremos-este-paper-con-elmodelo-que"
& "C:\Users\Usuario\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" german_gamma_modulo_2_horizonte_omega.py
```

O ejecutar:

```text
run_modulo_2_horizonte_omega.bat
```

## Resultado actual

```text
decision_global = H1
intervalo_ruptura = 113
omega_critico = 0.65
k_apelacion = 3
omega_final = 0.7524413246
```

## Salidas

| Archivo | Funcion |
|---|---|
| `gg_resultado_ventanas.csv` | serie temporal de terminos y Omega |
| `gg_modulo_2_resumen.json` | decision global y parametros |

