#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
German-Gamma Modulo 1: Estado Padre e Induccion de Medida

Autor y Titular Conceptual: Andres German Garcia
Copyright: (c) 2026 Andres German Garcia. Todos los derechos reservados.

Objetivo:
    Construir un Estado Padre sintetico (Omega, F, P), aplicar un operador de
    seleccion medible Gamma = 1_E y derivar la medida inducida P_Gamma.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def desplegar_modulo_1() -> dict[str, float | int | str]:
    print("=" * 80)
    print("       GERMAN-GAMMA MODULO 1: ESTADO PADRE E INDUCCION DE MEDIDA (P_Gamma)")
    print("=" * 80)

    # 1. Definicion del soporte del Estado Padre (Omega, F, P).
    np.random.seed(100)
    n_muestras = 5000
    print(f"[CONFIG] Construyendo Espacio Padre con N = {n_muestras} eventos basales...")

    current_parent = np.random.normal(50.0, 2.0, n_muestras)
    voltage_parent = np.random.normal(220.0, 3.0, n_muestras)
    temperature_parent = np.random.normal(40.0, 1.5, n_muestras)

    df_padre = pd.DataFrame(
        {
            "I": current_parent,
            "V": voltage_parent,
            "T": temperature_parent,
        }
    )

    # 2. Operador de Seleccion Gamma = 1_E.
    print("[OPERACION] Aplicando Operador de Seleccion Gamma = 1_E(omega)...")
    umbral_filtro_t = 41.5
    df_padre["Gamma"] = (df_padre["T"] > umbral_filtro_t).astype(int)

    p_gamma_1 = float(df_padre["Gamma"].mean())
    print(f"-> Probabilidad del evento de seleccion: P(Gamma = 1) = {round(p_gamma_1, 4)}")
    if p_gamma_1 <= 0:
        raise ValueError("P(Gamma=1) debe ser mayor que cero para definir P_Gamma.")

    # 3. Medida inducida P_Gamma.
    print("\n[COMPUTO] Derivando la nueva Medida Inducida P_Gamma (Estado Natural)...")
    df_inducido = df_padre[df_padre["Gamma"] == 1].copy()
    df_silenciado = df_padre[df_padre["Gamma"] == 0].copy()

    # 4. Verificacion operativa de continuidad absoluta.
    print("\n" + "-" * 60)
    print("          VERIFICACION DE CONTINUIDAD ABSOLUTA Y RADON-NIKODYM")
    print("-" * 60)
    print(f"Soporte Original (Estado Padre): Media T = {round(float(df_padre['T'].mean()), 4)} C")
    print(f"Medida Inducida (Estado Natural): Media T = {round(float(df_inducido['T'].mean()), 4)} C")

    # dP_Gamma / dP = 1_Gamma(omega) / P(Gamma = 1)
    derivada_rn_en_e = 1.0 / p_gamma_1
    derivada_rn_fuera_e = 0.0
    print(f"Valor RN dentro de E: dP_Gamma/dP = {round(derivada_rn_en_e, 4)}")
    print(f"Valor RN fuera de E:  dP_Gamma/dP = {round(derivada_rn_fuera_e, 4)}")

    resumen = {
        "modulo": "German-Gamma Modulo 1",
        "n_padre": int(len(df_padre)),
        "n_inducido": int(len(df_inducido)),
        "n_silenciado": int(len(df_silenciado)),
        "umbral_filtro_T": float(umbral_filtro_t),
        "P_Gamma_1": p_gamma_1,
        "media_T_padre": float(df_padre["T"].mean()),
        "media_T_inducido": float(df_inducido["T"].mean()),
        "media_T_silenciado": float(df_silenciado["T"].mean()),
        "RN_dentro_E": float(derivada_rn_en_e),
        "RN_fuera_E": float(derivada_rn_fuera_e),
        "absoluta_continuidad": "P_Gamma << P",
    }

    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True)
    df_padre.to_csv(out_dir / "gg_estado_padre.csv", index=False)
    df_inducido.to_csv(out_dir / "gg_medida_inducida.csv", index=False)
    df_silenciado.to_csv(out_dir / "gg_informacion_silenciada.csv", index=False)
    (out_dir / "gg_modulo_1_resumen.json").write_text(
        json.dumps(resumen, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("[OK] Exportado: outputs/gg_estado_padre.csv")
    print("[OK] Exportado: outputs/gg_medida_inducida.csv")
    print("[OK] Exportado: outputs/gg_informacion_silenciada.csv")
    print("[OK] Exportado: outputs/gg_modulo_1_resumen.json")
    print("=" * 80 + "\n")
    return resumen


if __name__ == "__main__":
    desplegar_modulo_1()
