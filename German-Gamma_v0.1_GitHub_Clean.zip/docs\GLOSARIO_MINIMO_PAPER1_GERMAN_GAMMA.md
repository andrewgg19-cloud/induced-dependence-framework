# Glosario Mínimo German-Gamma para Paper 1

**Autor y Titular Conceptual:** Andres German Garcia  
**Copyright:** (c) 2026 Andres German Garcia. Todos los derechos reservados.  
**Uso:** versión mínima para paper piloto, presentación metodológica y revisión externa.

---

## Regla Editorial

German-Gamma puede usar analogías para orientar el lenguaje, pero el paper debe sostenerse en operaciones cuantitativas.

> La analogía orienta; la métrica define.

Toda afirmación cualitativa debe quedar respaldada por una deformación cuantitativa trazable.

---

## 1. Estado Padre

### Definición

El Estado Padre es el espacio probabilístico antes de aplicar el filtro crítico:

\[
(\Omega,\mathcal{F},P)
\]

donde \(\Omega\) es el conjunto de eventos, \(\mathcal{F}\) la familia de eventos evaluables y \(P\) la medida original.

### Función

Sirve como soporte base contra el cual se mide si una selección, ventana o filtro cambió la composición del sistema.

---

## 2. Operador de Selección \(\Gamma\)

### Definición

\[
\Gamma:\Omega\rightarrow\{0,1\}
\]

\[
\Gamma(\omega)=\mathbf{1}_E(\omega)
\]

con:

\[
E\in\mathcal{F}
\]

\[
\Gamma(\omega)=1
\quad \text{si el evento sobrevive}
\]

\[
\Gamma(\omega)=0
\quad \text{si el evento queda fuera del resultado}
\]

### Función

Representa filtros, ventanas temporales, umbrales, reglas de aceptación, postselección o decisiones de software.

### Medibilidad

Al definirse como función indicadora de un evento medible \(E\in\mathcal{F}\), \(\Gamma\) es medible respecto a \(\mathcal{F}\). Esto garantiza que la selección no sale del soporte probabilístico formal.

---

## 3. Medida Inducida

### Definición

\[
P_\Gamma(A)=P(A\mid \Gamma=1)
\]

\[
P_\Gamma(A)=
\frac{P(A\cap\{\Gamma=1\})}{P(\Gamma=1)}
\]

si:

\[
P(\Gamma=1)>0
\]

### Radon-Nikodym

\[
\frac{dP_\Gamma}{dP}(\omega)
=
\frac{\mathbf{1}_{\Gamma}(\omega)}{P(\Gamma=1)}
\]

### Continuidad Absoluta

Dado que \(P(\Gamma=1)>0\), si \(P(A)=0\), entonces:

\[
P_\Gamma(A)=
\frac{P(A\cap\{\Gamma=1\})}{P(\Gamma=1)}
=0
\]

Por tanto:

\[
P_\Gamma\ll P
\]

y existe la derivada de Radon-Nikodym.

### Función

Permite tratar el resultado filtrado como una nueva medida probabilística, no como una simple reducción de tamaño muestral.

---

## 4. Estado Natural

### Definición

El Estado Natural es el subconjunto real observado después de aplicar \(\Gamma\):

\[
P_\Gamma
\]

En análisis temporal, puede representarse como:

\[
R_t=P(X\mid W_t,\Gamma=1)
\]

### Función

Es la expresión empírica real del sistema bajo el filtro o ventana aplicada.

---

## 5. Clon Neutro

### Definición

El clon neutro es un control contrafactual comparable al Estado Natural, generado bajo restricciones equivalentes pero rompiendo la composición específica del filtro real:

\[
N_\Gamma^*
\]

### Función

Pregunta:

> ¿La estructura observada aparece también bajo una geometría neutral comparable?

### Comparación

\[
D(P_\Gamma,N_\Gamma^*)
\]

o preferentemente:

\[
D_{JS}(P_\Gamma,N_\Gamma^*)
\]

---

## 6. Punto Neutro

### Definición

El punto neutro es el origen local de mínima deformación:

\[
\nu_t
\]

Distancia:

\[
\Psi_t=D(R_t,\nu_t)
\]

Para el Paper 1 se recomienda usar una métrica informacional explícita:

\[
D(R_t,\nu_t)=\sqrt{D_{JS}(R_t,\nu_t)}
\]

cuando \(R_t\) y \(\nu_t\) sean distribuciones. Si se trabaja sobre parámetros físicos normalizados, puede usarse distancia euclidiana:

\[
D(R_t,\nu_t)=\|z(R_t)-z(\nu_t)\|_2
\]

donde \(z(\cdot)\) representa coordenadas normalizadas.

### Función

Sirve como referencia basal. No representa ausencia absoluta de variabilidad, sino una posición local de comparación.

---

## 7. Entropía

### Definición

\[
H(R_t)=
-\sum_i p_i(t)\log p_i(t)
\]

con:

\[
0\log0=0
\]

Entropía normalizada:

\[
H^*(R_t)=\frac{H(R_t)}{\log m}
\]

para \(m>1\).

### Brecha Entrópica

\[
\Delta H_t=
|H^*(R_t)-H^*(N_t)|
\]

### Función

Mide reorganización informacional y permite detectar si el orden observado fue producido por selección, concentración o pérdida de diversidad.

---

## 8. Divergencia Jensen-Shannon

### Definición

\[
M=\frac{1}{2}(P+Q)
\]

\[
D_{JS}(P,Q)=
\frac{1}{2}D_{KL}(P||M)
+
\frac{1}{2}D_{KL}(Q||M)
\]

donde:

\[
D_{KL}(P||Q)=\sum_i p_i\log\frac{p_i}{q_i}
\]

### Función

Mide la separación entre estado observado y clon neutro. Con logaritmo base 2:

\[
D_{JS}(P,Q)\in[0,1]
\]

---

## 9. Sombra

### Definición General

La sombra es la huella cuantitativa dejada por una selección, ventana o transformación sobre la geometría probabilística.

### Sombra Geométrica

Para tasas de aceptación 2x2:

\[
r_{ab}=P(\Gamma=1\mid a,b)
\]

\[
I_G=
\frac{r_{00}r_{11}}{r_{01}r_{10}}
\]

\[
D_G=|\log I_G|
\]

### Sombra Composicional

Para un funcional \(F\):

\[
C_F=
F(P_\Gamma)-\mathbb{E}[F(N_\Gamma^*)]
\]

### Función

La sombra permite distinguir deformación de soporte y deformación de composición.

---

## 10. Horizonte German-Gamma \(\Omega_t\)

### Definición

Índice compuesto normalizado de reorganización:

\[
\Omega(W_t)
=
\alpha D_{JS}^{*}
+
\beta \mathcal{S}^{*}
+
\gamma(1-E^{*})
+
\delta\Delta H^{*}
+
\eta\Psi^{*}
\]

con:

\[
\alpha+\beta+\gamma+\delta+\eta=1
\]

\[
\alpha,\beta,\gamma,\delta,\eta\geq0
\]

y:

\[
X^*\in[0,1]
\]

### Micro-Glosario de Normalización

Cada término debe calcularse antes del análisis mediante una regla fija:

| Término | Definición operacional |
|---|---|
| \(D_{JS}^{*}\) | \(D_{JS}(R_t,N_t)\), con log base 2 |
| \(\mathcal{S}^{*}\) | sombra normalizada, por ejemplo \(\min(1,D_G/\tau_G)\) o \(\min(1,|C_F|/\tau_C)\) |
| \(E^{*}\) | elasticidad espejo normalizada en \([0,1]\) |
| \(\Delta H^{*}\) | \(|H^*(R_t)-H^*(N_t)|\) |
| \(\Psi^{*}\) | \(\min(1,D(R_t,\nu_t)/\tau_\nu)\) |

Los umbrales \(\tau_G,\tau_C,\tau_\nu\) deben declararse antes del análisis.

### Función

Resume divergencia, sombra, pérdida de elasticidad, brecha entrópica y distancia al punto neutro.

---

## 11. Apelación Temporal

### Definición

Una firma no se considera reorganización estructural por un solo cruce de umbral.

Alerta:

\[
\Omega(W_t)>\Omega_c
\]

Confirmación:

\[
\Omega(W_t),\Omega(W_{t+1}),...,\Omega(W_{t+k-1})>\Omega_c
\]

### Función

El tiempo funciona como instancia de apelación. Una firma debe persistir durante \(k\) ventanas para confirmarse.

### Elección de \(k\)

\(k\) debe fijarse antes del análisis. Regla recomendada:

\[
k=\max\left(2,\left\lceil\frac{\ell_c}{s}\right\rceil\right)
\]

donde:

| Símbolo | Significado |
|---|---|
| \(\ell_c\) | longitud de correlación temporal estimada en el clon neutro |
| \(s\) | paso entre ventanas consecutivas |

Si no se estima \(\ell_c\), debe reportarse una elección conservadora predefinida, por ejemplo \(k=3\), junto con análisis de sensibilidad.

---

## 12. Hipótesis y Decisión

### Hipótesis Nula

\[
H_0:
\Omega(W_t)\leq\Omega_c
\]

sin persistencia crítica.

### Hipótesis Alternativa

\[
H_1:
\Omega(W_t)>\Omega_c
\]

durante \(k\) ventanas consecutivas.

### Regla de Decisión

\[
H_1=
\begin{cases}
1, & \Omega(W_t)>\Omega_c \text{ durante } k \text{ ventanas consecutivas}\\
0, & \text{en caso contrario}
\end{cases}
\]

---

## Cierre

German-Gamma Paper 1 debe presentarse como un marco operacional para medir si una geometría probabilística observacional permanece neutral, se deforma o se reorganiza bajo filtros, ventanas y controles contrafactuales.

Forma mínima:

\[
P
\xrightarrow{\Gamma}
P_\Gamma
\xrightarrow{F}
Resultado
\xrightarrow{\mathcal{I}}
Interpretación
\]
