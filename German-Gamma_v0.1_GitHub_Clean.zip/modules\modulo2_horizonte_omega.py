#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
German-Gamma Modulo 2: Sonda Forense y Horizonte Omega

Autor y Titular Conceptual: Andres German Garcia
Copyright: (c) 2026 Andres German Garcia. Todos los derechos reservados.

Objetivo:
    Construir una sonda temporal que calcula el horizonte Omega por ventanas,
    aplica apelacion temporal y emite decision H0/H1.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def normalize_distribution(values: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    values = np.clip(values, 0.0, None)
    total = float(values.sum())
    if total <= eps:
        raise ValueError("La distribucion no puede normalizarse porque su masa total es cero.")
    return values / total


def kl_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    p = normalize_distribution(p)
    q = normalize_distribution(q)
    p_safe = np.clip(p, eps, 1.0)
    q_safe = np.clip(q, eps, 1.0)
    return float(np.sum(p_safe * np.log2(p_safe / q_safe)))


def calcular_divergencia_js(p: np.ndarray, q: np.ndarray) -> float:
    """Divergencia Jensen-Shannon en log base 2, acotada en [0, 1]."""
    p = normalize_distribution(p)
    q = normalize_distribution(q)
    m = 0.5 * (p + q)
    js = 0.5 * kl_divergence(p, m) + 0.5 * kl_divergence(q, m)
    return float(np.clip(js, 0.0, 1.0))


def elegir_k_apelacion(longitud_correlacion: int, paso_ventana: int) -> int:
    if paso_ventana <= 0:
        raise ValueError("paso_ventana debe ser mayor que cero.")
    return int(max(2, np.ceil(longitud_correlacion / paso_ventana)))


def desplegar_modulo_2() -> dict[str, object]:
    print("=" * 80)
    print("         GERMAN-GAMMA MODULO 2: SONDA FORENSE Y HORIZONTE OMEGA")
    print("=" * 80)

    pasos_tiempo = 120
    print(f"[CONFIG] Analizando serie temporal de {pasos_tiempo} intervalos...")

    omega_critico = 0.65
    paso_ventana = 1
    longitud_correlacion_neutra = 3
    k_apelacion = elegir_k_apelacion(longitud_correlacion_neutra, paso_ventana)
    consecutivos_sobre_umbral = 0
    h1_confirmada = False
    intervalo_ruptura = None

    pesos = {
        "alpha_d_js": 0.25,
        "beta_sombra": 0.20,
        "gamma_elasticidad": 0.15,
        "delta_brecha_h": 0.20,
        "eta_psi": 0.20,
    }
    suma_pesos = sum(pesos.values())
    if not np.isclose(suma_pesos, 1.0):
        raise ValueError(f"Los pesos de Omega deben sumar 1. Suma actual: {suma_pesos}")

    print("[PROCESAMIENTO] Deslizando ventanas W_t. Extrayendo vectores geometricos...")

    ventanas: list[dict[str, float | int | bool]] = []
    for t in range(pasos_tiempo):
        # Caso piloto severo: a partir del paso 80 crece una deformacion latente.
        deformacion = 0.0 if t < 80 else (t - 80) * 0.04

        # Distribucion observada vs clon neutro para JS real.
        neutral = np.array([0.25, 0.25, 0.25, 0.25])
        observed = np.array(
            [
                0.25 + deformacion,
                0.25 + 0.4 * deformacion,
                max(0.0, 0.25 - 0.7 * deformacion),
                max(0.0, 0.25 - 0.7 * deformacion),
            ]
        )
        d_js = calcular_divergencia_js(observed, neutral)

        # Terminos ya normalizados en [0, 1].
        s_sombra = float(np.clip(0.15 + deformacion * 0.5, 0.0, 1.0))
        elasticidad_espejo = float(np.clip(0.90 - deformacion * 0.6, 0.0, 1.0))
        brecha_h = float(np.clip(0.05 + deformacion * 0.4, 0.0, 1.0))
        psi_distancia = float(np.clip(0.10 + deformacion * 0.7, 0.0, 1.0))

        omega = (
            pesos["alpha_d_js"] * d_js
            + pesos["beta_sombra"] * s_sombra
            + pesos["gamma_elasticidad"] * (1.0 - elasticidad_espejo)
            + pesos["delta_brecha_h"] * brecha_h
            + pesos["eta_psi"] * psi_distancia
        )
        omega = float(np.clip(omega, 0.0, 1.0))

        sobre_umbral = omega > omega_critico
        if sobre_umbral:
            consecutivos_sobre_umbral += 1
            if consecutivos_sobre_umbral >= k_apelacion and not h1_confirmada:
                h1_confirmada = True
                intervalo_ruptura = t
        else:
            consecutivos_sobre_umbral = 0

        ventanas.append(
            {
                "paso": t,
                "deformacion": float(deformacion),
                "d_js": float(d_js),
                "sombra": s_sombra,
                "elasticidad_espejo": elasticidad_espejo,
                "brecha_h": brecha_h,
                "psi_distancia": psi_distancia,
                "omega": omega,
                "sobre_umbral": bool(sobre_umbral),
            }
        )

    df_horizonte = pd.DataFrame(ventanas)
    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True)
    df_horizonte.to_csv(out_dir / "gg_resultado_ventanas.csv", index=False)

    print("\n" + "-" * 60)
    print("               DICTAMEN FORMAL DE LA APELACION TEMPORAL")
    print("-" * 60)
    print(f"Estatus del Horizonte Critico (Omega_c): {omega_critico}")
    print(f"k de apelacion temporal: {k_apelacion}")
    if h1_confirmada:
        print("VEREDICTO: Hipotesis Alternativa H_1 Activa.")
        print(f"-> Reorganizacion estructural confirmada en el paso: {intervalo_ruptura}")
        print(f"-> El tiempo valido la firma geometrica durante k = {k_apelacion} ventanas consecutivas.")
    else:
        print("VEREDICTO: Hipotesis Nula H_0 Sostenida. El espacio-tiempo se mantiene plano.")
    print("=" * 80 + "\n")

    resumen = {
        "modulo": "German-Gamma Modulo 2",
        "pasos_tiempo": pasos_tiempo,
        "omega_critico": omega_critico,
        "k_apelacion": k_apelacion,
        "longitud_correlacion_neutra": longitud_correlacion_neutra,
        "paso_ventana": paso_ventana,
        "pesos": pesos,
        "decision_global": "H1" if h1_confirmada else "H0",
        "intervalo_ruptura": intervalo_ruptura,
        "omega_final": float(df_horizonte.iloc[-1]["omega"]),
        "max_omega": float(df_horizonte["omega"].max()),
    }
    (out_dir / "gg_modulo_2_resumen.json").write_text(
        json.dumps(resumen, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print("[OK] Exportado: outputs/gg_resultado_ventanas.csv")
    print("[OK] Exportado: outputs/gg_modulo_2_resumen.json")
    return resumen


if __name__ == "__main__":
    desplegar_modulo_2()
