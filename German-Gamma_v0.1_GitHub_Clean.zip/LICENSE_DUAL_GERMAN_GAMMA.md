# Licencia Dual German-Gamma v3

```text
Autor y titular conceptual:
Andres German Garcia

Copyright:
(c) 2026 Andres German Garcia.

Framework:
German-Gamma / Framework de Auditoria Forense German-Gamma.
```

## 1. Licencia abierta academica

Se autoriza el uso gratuito del framework German-Gamma v3 para:

```text
1. Profesores.
2. Investigadores.
3. Alumnos.
4. Revisores academicos.
5. Proyectos educativos sin fines de lucro.
6. Reproduccion, verificacion y discusion cientifica no comercial.
```

Condiciones:

```text
1. Citar al autor: Andres German Garcia.
2. Mantener avisos de copyright.
3. No remover el manifiesto metodologico.
4. No registrar el framework como obra propia.
5. No vender auditorias, reportes o servicios derivados sin licencia comercial.
```

## 2. Licencia comercial

Se requiere licencia comercial cuando una persona, empresa, consultora, despacho, laboratorio, institucion o tercero use German-Gamma v3 para obtener beneficio economico directo o indirecto.

Ejemplos:

```text
1. Auditorias pagadas.
2. Reportes periciales remunerados.
3. Consultoria tecnica.
4. Integracion en software comercial.
5. Uso por empresas para validar, impugnar o certificar datos.
6. Uso institucional en contratos, litigios, seguros, certificaciones o compliance.
```

## 3. Propuesta de tarifas comerciales

Estas tarifas son una propuesta inicial y pueden ajustarse por contrato, jurisdiccion, alcance tecnico y nivel de responsabilidad.

| Tipo de licencia | Uso permitido | Tarifa sugerida |
| :--- | :--- | ---: |
| Comercial individual | Un consultor independiente, hasta 3 auditorias al ano | USD 1,500 - 3,000 / ano |
| Profesional pequena | Equipo de hasta 5 usuarios, auditorias comerciales limitadas | USD 5,000 - 12,000 / ano |
| Institucional | Universidad privada, laboratorio, despacho o empresa mediana | USD 15,000 - 35,000 / ano |
| Empresarial / pericial | Uso en litigio, certificacion, compliance o auditoria con alto impacto economico | USD 40,000 - 100,000 / ano |
| Licencia por caso | Una auditoria comercial puntual | 3% - 8% del valor del contrato, minimo USD 2,500 |

## 4. Recomendacion comercial

Para iniciar publicamente sin cerrar puertas:

```text
Academico no comercial:
gratis con atribucion.

Comercial:
licencia obligatoria.

Uso pericial o litigioso:
contrato especifico.
```

## 5. Reserva de derechos

Todo uso no autorizado fuera de la licencia academica no comercial queda reservado al autor.

Esta licencia no transfiere titularidad intelectual, marca, autoria conceptual ni derechos de explotacion comercial no pactados expresamente.
