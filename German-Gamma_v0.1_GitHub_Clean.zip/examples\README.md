# Examples

This folder is reserved for small reproducible example inputs.

The current modules generate their own synthetic pilot data and write outputs locally.

